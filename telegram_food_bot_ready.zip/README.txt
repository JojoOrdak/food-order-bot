# بات سفارش ساندویچ

## 1) ساخت بات
در تلگرام به @BotFather برو و `/newbot` را بزن.
توکن را دریافت کن و به هیچ‌کس ارسال نکن.

## 2) نصب
Python 3.11 یا جدیدتر نصب باشد:

```bash
pip install -r requirements.txt
```

## 3) تنظیم توکن

### Windows PowerShell
```powershell
$env:BOT_TOKEN="توکن_بات"
python bot.py
```

### Linux / macOS
```bash
export BOT_TOKEN="توکن_بات"
python bot.py
```

## 4) وصل کردن رسیدها به صاحب بات
بعد از اجرای بات، با اکانت صاحب بات داخل همان بات `/myid` را بفرست.
عدد نمایش‌داده‌شده را بردار.

### Windows PowerShell
```powershell
$env:OWNER_CHAT_ID="عدد_نمایش_داده_شده"
python bot.py
```

### Linux / macOS
```bash
export OWNER_CHAT_ID="عدد_نمایش_داده_شده"
python bot.py
```

حالا هر عکس رسیدی که مشتری در بات ارسال کند، همراه اطلاعات سفارش برای صاحب بات ارسال می‌شود.

## نکته
برای کارکرد 24 ساعته، برنامه باید روی یک سرور/VPS یا سرویس اجرای دائمی اجرا شود.
